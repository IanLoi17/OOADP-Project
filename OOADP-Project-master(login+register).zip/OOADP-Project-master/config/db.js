module.exports = {
    host: 'localhost',
    database: 'selfcarerecords',
    username: 'itp211',
    password: 'itp211'
}