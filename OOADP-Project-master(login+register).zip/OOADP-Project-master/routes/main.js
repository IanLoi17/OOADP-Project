const express = require('express');
const router = express.Router();

// Home page
router.get('/', (req, res) => {
    const title = 'Welcome to Selfcare';
    res.render('index', {title: title});
});

// Display medical records for the current patient
router.get('/showMedicalRecords', (req, res) => {
    res.render('medicalrecords/displayMedicRecords');
});

// Enter medical records for the current patient
router.get('/enterMedicalRecords', (req, res) => {
    res.render('medicalrecords/enterRecords');
});

module.exports = router;